#ifndef GAME
#define GAME
#include <SFML/Graphics.hpp> 
#include"Well.h"
#include"Tetrimino.h"
#include<SFML/Audio.hpp>

enum GameState {TETRIS_SPLASH,TETRIS_PLAY,TETRIS_GAME_OVER,TETRIS_HIGHSCORE};

const int LAYOUT_WINDOW_WIDTH = 800;
const int LAYOUT_WINDOW_HEIGHT = 650;
const int LAYOUT_BOARD_TOP = 30;
const int LAYOUT_BOARD_LEFT = 50;
const int BLOCK_SIZE_PIXEL = 25;
//==============================temp==================================
const int BLOCK = 50;
//====================================================================

class Game
{
private:
	sf::RenderWindow Window;
	Well *MyWell;
	Tetrimino* TetriminoInPlay;
	Tetrimino *TetriminoOnDeck;
	//==============================
	//Image
	//splash screen
	sf::Texture SplashScreenImage;
	sf::Sprite SpriteImage;
	//game over screen
	sf::Texture GameOverImage;
	sf::Sprite SpriteGameOverImage;
	//==============================
	//font
	sf::Font MyFont;
	sf::Font ArcadeFont;
	sf::Font HaloFont;
	//========================
	//Text
	sf::Text GameOverTextWord1;
	sf::Text GameOverTextWord2;
	sf::Text GameOverScoreText;
	sf::Text HighScoreText1;
	sf::Text HighScoreText2;
	sf::Text PressBackspaceText;
	sf::Text BackspaceText;
	sf::Text PressText;
	//=========================
	//Shapes

	//temp
	sf::RectangleShape TTetrimino1;
	sf::RectangleShape TTetrimino2;
	sf::RectangleShape TTetrimino3;
	sf::RectangleShape TTetrimino4;
	//=========================
	//sound Or Music
	sf::Sound sound;
	sf::SoundBuffer soundBuffer;
	sf::Music Music;
	//========================
	sf::Event event;
	int Score;
	GameState ProcessGameScreen();
	GameState ProcessSplashScreen();
	GameState ProcessGameOverScreen();
	GameState ProcessHighScoreScreen();
	void DrawWell(Well MyWell, int LocationTop, int LocationSide, int BlockPixel);
	sf::Color ConvertToSfmlColor(char Color);
	void DrawTetrimino(Tetrimino TetriminoInPlay, int LocationTop, int LocationSide,int BlockPixel);
public:

	//constructor 
	Game();
	void PlayGame();
};

#endif